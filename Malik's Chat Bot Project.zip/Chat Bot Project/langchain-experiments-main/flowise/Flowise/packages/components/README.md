<!-- markdownlint-disable MD030 -->

# Flowise Components

Apps integration for Flowise. Contain Nodes and Credentials.

![Flowise](https://github.com/FlowiseAI/Flowise/blob/main/images/flowise.gif?raw=true)

Install:

```bash
npm i flowise-components
```

## License

Source code in this repository is made available under the [MIT License](https://github.com/FlowiseAI/Flowise/blob/master/LICENSE.md).
